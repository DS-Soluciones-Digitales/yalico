import { useState, useEffect } from "react";
import type { CurrencyCode, ExchangeRateResponse } from "../types";
import { isAllowed } from "../types/currencies";
import { fetchExchangeRate } from "../mocks/exchangeService";

export function useExchangeRate(from: CurrencyCode, to: CurrencyCode) {
  const [data, setData] = useState<ExchangeRateResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!isAllowed(from, to)) return;

    setLoading(true);
    setError(null);

    fetchExchangeRate(from, to)
      .then(setData)
      .catch((e:any) => setError(e.message))
      .finally(() => setLoading(false));
  }, [from, to]);

  const latestRate = data?.exchangeRates.at(-1)?.exchangeRate ?? null;

  return { data, loading, error, latestRate };
}
