import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Tooltip,
  Filler,
} from "chart.js";
import { Line } from "react-chartjs-2";
import type { ExchangeRateEntry } from "../types";

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Filler);

interface Props {
  rates: ExchangeRateEntry[];
}

function formatLabel(dateStr: string): string {
  const d = new Date(dateStr);
  return `${d.getDate().toString().padStart(2, "0")}.${(d.getMonth() + 1)
    .toString()
    .padStart(2, "0")}`;
}

export function RateChart({ rates }: Props) {
  const labels = rates.map((r) => formatLabel(r.date));
  const values = rates.map((r) => r.exchangeRate);

  const data = {
    labels,
    datasets: [
      {
        data: values,
        borderColor: "#3b82f6",
        backgroundColor: "rgba(59,130,246,0.08)",
        pointBackgroundColor: "#3b82f6",
        pointRadius: 5,
        pointHoverRadius: 7,
        tension: 0.35,
        fill: true,
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: { legend: { display: false }, tooltip: { mode: "index" as const } },
    scales: {
      x: { grid: { display: false }, ticks: { font: { size: 11 } } },
      y: {
        grid: { color: "#f0f0f0" },
        ticks: { font: { size: 11 } },
        suggestedMin: Math.min(...values) * 0.995,
        suggestedMax: Math.max(...values) * 1.005,
      },
    },
  };

  return (
    <div className="w-full h-52">
      <p className="text-xs text-gray-400 text-center mb-1">Últimos 5 días</p>
      <Line data={data} options={options} />
    </div>
  );
}
