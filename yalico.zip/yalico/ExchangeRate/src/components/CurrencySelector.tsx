import type { CurrencyCode } from "../types";
import { CURRENCIES, isAllowed } from "../types/currencies";

interface Props {
  value: CurrencyCode;
  onChange: (code: CurrencyCode) => void;
  disabledFor?: CurrencyCode; // Se deshabilita si la opción no es compatible con esta moneda (usado para evitar selecciones inválidas en el selector "to" basado en la selección "from")
  className?: string;
}

export function CurrencySelector({ value, onChange, disabledFor, className }: Props) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value as CurrencyCode)}
      className={`
        h-10
        border border-gray-200
        rounded-lg
        px-3
        text-sm
        text-gray-700
        focus:outline-none focus:ring-2 focus:ring-blue-400
        bg-white
        ${className ?? ""}
      `}
    >
      {CURRENCIES.map((c) => {
        const disabled =
          disabledFor !== undefined &&
          c.code !== value &&
          !isAllowed(disabledFor, c.code);
        return (
          <option key={c.code} value={c.code} disabled={disabled}>
            {disabled ? `${c.label} (no permitido)` : c.label}
          </option>
        );
      })}
    </select>
  );
}
