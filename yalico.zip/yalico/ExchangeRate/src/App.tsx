import { useState, useEffect } from "react";
import type { CurrencyCode } from "./types";
import { getCurrency, isAllowed, ALLOWED_PAIRS } from "./types/currencies";
import { useExchangeRate } from "./hooks/useExchangeRate";
import { CurrencySelector } from "./components/CurrencySelector";
import { RateChart } from "./components/RateChart";

export default function App() {
  const [from, setFrom] = useState<CurrencyCode>("EUR");
  const [to, setTo] = useState<CurrencyCode>("USD");
  const [amountFrom, setAmountFrom] = useState("1");
  const [amountTo, setAmountTo] = useState("");

  const { data, loading, latestRate } = useExchangeRate(from, to);

  const fromCurrency = getCurrency(from);
  const toCurrency = getCurrency(to);

  useEffect(() => {
    if (latestRate !== null) {
      setAmountFrom("1");
      setAmountTo(latestRate.toFixed(4));
    }
  }, [latestRate, from, to]);

  // Cuando se cambia el monto "from", se recalcula el monto "to" usando la tasa de cambio más reciente. Si el campo "from" queda vacío, el campo "to" también se vacía.
  const handleAmountFromChange = (val: string) => {
    setAmountFrom(val);
    if (latestRate !== null && val !== "") {
      setAmountTo((parseFloat(val) * latestRate).toFixed(4));
    } else {
      setAmountTo("");
    }
  };

  // Similar a handleAmountFromChange pero en sentido inverso. Permite que el usuario ingrese un valor en el campo "to" y calcula automáticamente el equivalente en "from" usando la tasa de cambio actual.
  const handleAmountToChange = (val: string) => {
    setAmountTo(val);
    if (latestRate !== null && val !== "") {
      setAmountFrom((parseFloat(val) / latestRate).toFixed(4));
    } else {
      setAmountFrom("");
    }
  };
  // Cuando se cambia la moneda "from", se verifica si la moneda "to" sigue siendo válida. Si no lo es, se actualiza automáticamente a una opción permitida. Esto asegura que el usuario siempre tenga una combinación válida de monedas seleccionada.
  const handleFromChange = (code: CurrencyCode) => {
    setFrom(code);
    if (!isAllowed(code, to)) {
      setTo(ALLOWED_PAIRS[code][0]);
    }
  };

  const serverInfo = data
    ? `${new Date().toLocaleDateString("es-PE")} ${new Date().toLocaleTimeString("es-PE", {
      hour: "2-digit",
      minute: "2-digit",
    })} - Obtenido de ${data.server}`
    : null;

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-6">
      <div>
        <div className="bg-white rounded-2xl shadow-md border border-gray-100 overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-gray-100">

            <div className="p-6 flex flex-col gap-5">
              {/* Header text */}
              <div>
                <p className="text-sm text-gray-500">
                  1 {fromCurrency.label} equivale a
                </p>
                <p className="text-3xl font-bold text-gray-800 leading-tight">
                  {loading ? "…" : latestRate !== null ? latestRate.toFixed(4) : "—"}{" "}
                  {toCurrency.label}
                </p>
                <p className="text-xs text-gray-400 mt-1">
                  {loading ? "Cargando..." : serverInfo ?? "—"}
                </p>
              </div>

              <div className="grid grid-cols-1 gap-2">
                {/* Input from */}
                <div className="flex gap-2">
                  <input
                    type="number"
                    value={amountFrom}
                    onChange={(e) => handleAmountFromChange(e.target.value)}
                    className="flex-1 h-10 appearance-none border border-gray-200 rounded-lg px-3 text-right text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-400"
                    min="0"
                  />
                  <CurrencySelector
                    value={from}
                    onChange={handleFromChange}
                    disabledFor={to}
                    className="w-32"
                  />
                </div>

                {/* Input to */}
                <div className="flex gap-2 items-center">
                  <input
                    type="number"
                    value={amountTo}
                    onChange={(e) => handleAmountToChange(e.target.value)}
                    className="flex-1 h-10 appearance-none border border-gray-200 rounded-lg px-3 text-right text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-400"
                    min="0"
                  />
                  <CurrencySelector
                    value={to}
                    onChange={setTo}
                    disabledFor={from}
                    className="w-32"
                  />
                </div>

              </div>
            </div>

            {/* Right panel — chart */}
            <div className="p-6 flex flex-col justify-center">
              {data ? (
                <RateChart rates={data.exchangeRates} />
              ) : (
                <div className="flex items-center justify-center h-52 text-gray-300 text-sm">
                  {loading ? "Cargando gráfica..." : "Sin datos"}
                </div>
              )}
            </div>

          </div>
        </div>
      </div>
    </div>
  );
}
