import type { CurrencyCode, ExchangeRateResponse } from "../types";

// Static mock data — simulates what the backend would return.
// Rates are for the last 5 days relative to today.
const MOCK_DATA: Record<string, ExchangeRateResponse> = {
  "USD-EUR": {
    from: "USD", to: "EUR", server: "servidor propio",
    exchangeRates: [
      { date: "2026-04-05T00:00:00.000Z", exchangeRate: 1.14 },
      { date: "2026-04-06T00:00:00.000Z", exchangeRate: 1.18 },
      { date: "2026-04-07T00:00:00.000Z", exchangeRate: 1.17 },
      { date: "2026-04-08T00:00:00.000Z", exchangeRate: 1.16 },
      { date: "2026-04-09T00:00:00.000Z", exchangeRate: 1.15 },
    ],
  },
  "EUR-USD": {
    from: "EUR", to: "USD", server: "servidor propio",
    exchangeRates: [
      { date: "2026-04-05T00:00:00.000Z", exchangeRate: 1.10 },
      { date: "2026-04-06T00:00:00.000Z", exchangeRate: 1.09 },
      { date: "2026-04-07T00:00:00.000Z", exchangeRate: 1.11 },
      { date: "2026-04-08T00:00:00.000Z", exchangeRate: 1.08 },
      { date: "2026-04-09T00:00:00.000Z", exchangeRate: 1.10 },
    ],
  },
  "USD-PEN": {
    from: "USD", to: "PEN", server: "servidor propio",
    exchangeRates: [
      { date: "2026-04-05T00:00:00.000Z", exchangeRate: 3.72 },
      { date: "2026-04-06T00:00:00.000Z", exchangeRate: 3.75 },
      { date: "2026-04-07T00:00:00.000Z", exchangeRate: 3.73 },
      { date: "2026-04-08T00:00:00.000Z", exchangeRate: 3.76 },
      { date: "2026-04-09T00:00:00.000Z", exchangeRate: 3.74 },
    ],
  },
  "PEN-USD": {
    from: "PEN", to: "USD", server: "servidor propio",
    exchangeRates: [
      { date: "2026-04-05T00:00:00.000Z", exchangeRate: 0.269 },
      { date: "2026-04-06T00:00:00.000Z", exchangeRate: 0.267 },
      { date: "2026-04-07T00:00:00.000Z", exchangeRate: 0.268 },
      { date: "2026-04-08T00:00:00.000Z", exchangeRate: 0.266 },
      { date: "2026-04-09T00:00:00.000Z", exchangeRate: 0.268 },
    ],
  },
  "EUR-PEN": {
    from: "EUR", to: "PEN", server: "servidor propio",
    exchangeRates: [
      { date: "2026-04-05T00:00:00.000Z", exchangeRate: 4.10 },
      { date: "2026-04-06T00:00:00.000Z", exchangeRate: 4.12 },
      { date: "2026-04-07T00:00:00.000Z", exchangeRate: 4.08 },
      { date: "2026-04-08T00:00:00.000Z", exchangeRate: 4.15 },
      { date: "2026-04-09T00:00:00.000Z", exchangeRate: 4.11 },
    ],
  },
  "PEN-EUR": {
    from: "PEN", to: "EUR", server: "servidor propio",
    exchangeRates: [
      { date: "2026-04-05T00:00:00.000Z", exchangeRate: 0.244 },
      { date: "2026-04-06T00:00:00.000Z", exchangeRate: 0.243 },
      { date: "2026-04-07T00:00:00.000Z", exchangeRate: 0.245 },
      { date: "2026-04-08T00:00:00.000Z", exchangeRate: 0.241 },
      { date: "2026-04-09T00:00:00.000Z", exchangeRate: 0.243 },
    ],
  },
  "EUR-CNY": {
    from: "EUR", to: "CNY", server: "servidor propio",
    exchangeRates: [
      { date: "2026-04-05T00:00:00.000Z", exchangeRate: 7.95 },
      { date: "2026-04-06T00:00:00.000Z", exchangeRate: 7.98 },
      { date: "2026-04-07T00:00:00.000Z", exchangeRate: 7.92 },
      { date: "2026-04-08T00:00:00.000Z", exchangeRate: 8.01 },
      { date: "2026-04-09T00:00:00.000Z", exchangeRate: 7.97 },
    ],
  },
  "CNY-EUR": {
    from: "CNY", to: "EUR", server: "servidor propio",
    exchangeRates: [
      { date: "2026-04-05T00:00:00.000Z", exchangeRate: 0.126 },
      { date: "2026-04-06T00:00:00.000Z", exchangeRate: 0.125 },
      { date: "2026-04-07T00:00:00.000Z", exchangeRate: 0.126 },
      { date: "2026-04-08T00:00:00.000Z", exchangeRate: 0.125 },
      { date: "2026-04-09T00:00:00.000Z", exchangeRate: 0.126 },
    ],
  },
  "PEN-CNY": {
    from: "PEN", to: "CNY", server: "servidor propio",
    exchangeRates: [
      { date: "2026-04-05T00:00:00.000Z", exchangeRate: 1.95 },
      { date: "2026-04-06T00:00:00.000Z", exchangeRate: 1.97 },
      { date: "2026-04-07T00:00:00.000Z", exchangeRate: 1.94 },
      { date: "2026-04-08T00:00:00.000Z", exchangeRate: 1.98 },
      { date: "2026-04-09T00:00:00.000Z", exchangeRate: 1.96 },
    ],
  },
  "CNY-PEN": {
    from: "CNY", to: "PEN", server: "servidor propio",
    exchangeRates: [
      { date: "2026-04-05T00:00:00.000Z", exchangeRate: 0.513 },
      { date: "2026-04-06T00:00:00.000Z", exchangeRate: 0.508 },
      { date: "2026-04-07T00:00:00.000Z", exchangeRate: 0.515 },
      { date: "2026-04-08T00:00:00.000Z", exchangeRate: 0.505 },
      { date: "2026-04-09T00:00:00.000Z", exchangeRate: 0.510 },
    ],
  },
};

// Simulates a network call to /exchangeRate/{from}/{to}
export async function fetchExchangeRate(
  from: CurrencyCode,
  to: CurrencyCode
): Promise<ExchangeRateResponse> {
  await new Promise((r) => setTimeout(r, 300)); // simulate network delay
  const key = `${from}-${to}`;
  const data = MOCK_DATA[key];
  if (!data) throw new Error(`No exchange rate available for ${from} → ${to}`);
  return data;
}
