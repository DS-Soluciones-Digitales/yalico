import type { CurrencyCode, Currency } from "../types";

export const CURRENCIES: Currency[] = [
  { code: "USD", label: "Dólares US (US$)", symbol: "US$" },
  { code: "EUR", label: "Euro (€)", symbol: "€" },
  { code: "PEN", label: "Soles (S/.)", symbol: "S/." },
  { code: "CNY", label: "Yuanes (¥)", symbol: "¥" },
];

// Define cuales pares de monedas son válidos para la conversión. Esto se usa para habilitar/deshabilitar opciones en el selector y para validar antes de hacer la consulta.
export const ALLOWED_PAIRS: Record<CurrencyCode, CurrencyCode[]> = {
  USD: ["EUR", "PEN"],
  EUR: ["USD", "PEN", "CNY"],
  PEN: ["USD", "EUR", "CNY"],
  CNY: ["EUR", "PEN"],
};

// Función para verificar si una conversión entre dos monedas es permitida según ALLOWED_PAIRS. Esto se usa tanto en la UI para deshabilitar opciones no válidas como en la lógica de negocio para evitar consultas inválidas.
export const isAllowed = (from: CurrencyCode, to: CurrencyCode): boolean => {
  if (from === to) return false;
  return ALLOWED_PAIRS[from].includes(to);
};

// Función para obtener los detalles de una moneda dado su código. Esto se usa para mostrar el nombre completo y el símbolo de la moneda en la UI.
export const getCurrency = (code: CurrencyCode): Currency =>
  CURRENCIES.find((c) => c.code === code)!;
