export type CurrencyCode = "USD" | "EUR" | "PEN" | "CNY";

export interface Currency {
  code: CurrencyCode;
  label: string;
  symbol: string;
}

export interface ExchangeRateEntry {
  date: string;
  exchangeRate: number;
}

export interface ExchangeRateResponse {
  from: CurrencyCode;
  to: CurrencyCode;
  server: string;
  exchangeRates: ExchangeRateEntry[];
}
