# ExchangeRate

Aplicación web para consultar y convertir tipos de cambio entre varias monedas, con una interfaz simple y una gráfica de los últimos 5 días.

Este proyecto está desarrollado con React + TypeScript + Vite y usa datos mock para simular una API de tasas de cambio.

## Características

- Conversión bidireccional entre monedas (puedes editar ambos campos).
- Selección de moneda origen y destino con validación de pares permitidos.
- Actualización automática del monto convertido usando la tasa más reciente.
- Gráfica de línea con la evolución de la tasa en los últimos 5 días.
- Simulación de llamada de red para representar comportamiento real de backend.

## Tecnologías

- React 19
- TypeScript
- Vite
- Tailwind CSS
- Chart.js + react-chartjs-2
- ESLint

## Estructura del proyecto

La app se encuentra dentro de la carpeta ExchangeRate:

```text
ExchangeRate/
	src/
		components/
			CurrencySelector.tsx
			RateChart.tsx
		hooks/
			useExchangeRate.ts
		mocks/
			exchangeService.ts
		types/
			currencies.ts
			index.ts
		App.tsx
		main.tsx
```

## Monedas soportadas

- USD (Dólares US)
- EUR (Euro)
- PEN (Soles)
- CNY (Yuanes)

## Pares permitidos

No todos los pares están habilitados. La lógica actual permite:

- USD -> EUR, PEN
- EUR -> USD, PEN, CNY
- PEN -> USD, EUR, CNY
- CNY -> EUR, PEN

## Cómo ejecutar el proyecto

1. Entra a la carpeta del proyecto:

```bash
cd ExchangeRate
```

2. Instala dependencias:

```bash
npm install
```

3. Levanta el entorno de desarrollo:

```bash
npm run dev
```

4. Abre la URL que muestra Vite en consola (normalmente http://localhost:5173).

## Scripts disponibles

Desde la carpeta ExchangeRate:

- npm run dev: inicia el servidor de desarrollo.
- npm run build: compila TypeScript y genera build de producción.
- npm run preview: sirve localmente el build generado.
- npm run lint: ejecuta el análisis estático con ESLint.

## Datos y arquitectura

- El hook useExchangeRate centraliza la carga de datos y estado (loading/error/data).
- exchangeService.ts simula una API con datos estáticos y latencia artificial.
- App.tsx coordina selección de monedas, cálculo bidireccional y render de UI.
- RateChart.tsx renderiza la serie temporal de tasas usando Chart.js.

## Posibles mejoras

- Conectar con una API real de tipo de cambio.
- Agregar manejo visual de errores en la interfaz.
- Incluir pruebas unitarias y de integración.
- Agregar selector de rango histórico (7, 15, 30 días).

